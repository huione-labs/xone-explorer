export const data = {
  items: [
    {
      contract_address: '0x5cbe1b88b6357e6a8f0821bea72cc0b88c231f1c',
      created_at: '2022-05-27T01:13:48.000000Z',
      game_type: 0,
      index: 6662,
      l2_block_number: 12542890,
      resolved_at: null,
      status: 'In progress',
    },
    {
      contract_address: '0x5cbe1b88b6357e6a8f0821bea72cc0b88c231f1c',
      created_at: '2022-05-27T01:13:48.000000Z',
      game_type: 0,
      index: 6662,
      l2_block_number: 12542890,
      resolved_at: '2022-05-27T01:13:48.000000Z',
      status: 'Defender wins',
    },
  ],
  next_page_params: {
    items_count: 50,
    index: 8382363,
  },
};
