import { apps } from './apps';

export const ratings = {
  records: [
    {
      fields: {
        appId: apps[0].id,
        rating: 4.3,
        count: 15,
      },
    },
  ],
};
