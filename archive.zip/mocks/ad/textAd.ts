export const duck = {
  ad: {
    name: 'Hello utia!',
    description_short: 'Utia is the best! Go with utia! Utia is the best! Go with utia!',
    thumbnail: 'http://localhost:3100/utia.jpg',
    url: 'https://test.url',
    cta_button: 'Click me!',
  },
};
