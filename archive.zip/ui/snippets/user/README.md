Component in `/profile` directory are used when Account and WalletConnect features are enabled.
Component in `/wallet` directory are used when only WalletConnect features is enabled.