export interface FormFields {
  email: string;
  name: string;
  reCaptcha: string;
}
